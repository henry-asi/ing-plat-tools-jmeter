# Banco Exterior Microservice

## Requirements
* Java 25
* Maven

## Build
```bash
mvn clean install
```

## Unit tests
```bash
mvn test
```

## Coverage
```bash
mvn verify
```

El reporte HTML queda disponible en `target/site/jacoco/index.html` y el reporte XML en `target/site/jacoco/jacoco.xml`.

## Run
```bash
mvn spring-boot:run
```

## Docker
```bash
docker build -t ms-app .
```
