package com.bancoexterior.microservicio.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class SaludoServiceTest {

    private final SaludoService saludoService = new SaludoService();

    @Test
    void obtenerSaludoRetornaHolaMundo() {
        assertThat(saludoService.obtenerSaludo()).isEqualTo("Hola Mundo");
    }
}
