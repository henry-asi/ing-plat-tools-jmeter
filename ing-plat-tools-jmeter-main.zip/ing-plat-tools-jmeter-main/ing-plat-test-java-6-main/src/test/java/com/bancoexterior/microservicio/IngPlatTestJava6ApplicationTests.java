package com.bancoexterior.microservicio;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.boot.SpringApplication;

import static org.assertj.core.api.Assertions.assertThat;

class IngPlatTestJava6ApplicationTests {

    @Test
    void puedeConstruirLaAplicacion() {
        assertThat(new IngPlatTestJava6Application()).isNotNull();
    }

    @Test
    void mainIniciaLaAplicacion() {
        String[] args = {"--spring.profiles.active=local"};

        try (MockedStatic<SpringApplication> springApplication = Mockito.mockStatic(SpringApplication.class)) {
            IngPlatTestJava6Application.main(args);
            springApplication.verify(() -> SpringApplication.run(IngPlatTestJava6Application.class, args));
        }
    }
}
