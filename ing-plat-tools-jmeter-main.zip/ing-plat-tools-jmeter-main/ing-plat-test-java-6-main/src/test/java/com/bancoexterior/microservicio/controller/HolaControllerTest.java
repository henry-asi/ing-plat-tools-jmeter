package com.bancoexterior.microservicio.controller;

import com.bancoexterior.microservicio.service.SaludoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class HolaControllerTest {

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(new HolaController(new SaludoService())).build();
    }

    @Test
    void holaRetornaHolaMundo() throws Exception {
        mockMvc.perform(get("/hola"))
                .andExpect(status().isOk())
                .andExpect(content().string("Hola Mundo"));
    }
}
