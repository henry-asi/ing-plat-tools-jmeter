package com.bancoexterior.microservicio.controller;

import com.bancoexterior.microservicio.service.SaludoService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HolaController {

    private final SaludoService saludoService;

    public HolaController(SaludoService saludoService) {
        this.saludoService = saludoService;
    }

    @GetMapping("/hola")
    public String hola() {
        return saludoService.obtenerSaludo();
    }
}