package com.bancoexterior.microservicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngPlatTestJava6Application {

    public static void main(String[] args) {
        SpringApplication.run(IngPlatTestJava6Application.class, args);
    }

}
